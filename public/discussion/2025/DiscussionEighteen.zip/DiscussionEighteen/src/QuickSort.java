public class QuickSort {

    public static void main(String[] args) {
        int[] arr = {9, 3, 7, 6, 2, 8, 5, 1, 10, 4}; // 10-element array
        System.out.println("Original array:");
        printArray(arr);

        quickSort(arr, 0, arr.length - 1); // Quick Sort call

        System.out.println("\nSorted array:");
        printArray(arr);
    }

    // Quick Sort method
    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            // Partition index
            int pi = partition(arr, low, high);

            // Recursively sort the two sub-arrays
            quickSort(arr, low, pi - 1); // Left part
            quickSort(arr, pi + 1, high); // Right part
        }
    }

    // Partition method
    public static int partition(int[] arr, int low, int high) {
        // Pivot is the last element
        int pivot = arr[high];
        int i = low - 1; // Index for the smaller element

        // Re-arrange the array such that elements less than pivot are on the left,
        // and elements greater than pivot are on the right.
        for (int j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++; // Increment index for smaller element
                // Swap arr[i] and arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // Swap the pivot element to the correct position
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1; // Return partition index
    }

    // Helper method to print the array
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

