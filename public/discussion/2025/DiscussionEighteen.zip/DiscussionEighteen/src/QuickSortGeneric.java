public class QuickSortGeneric {

    public static void main(String[] args) {
        Integer[] intArray = {9, 3, 7, 6, 2, 8, 5, 1, 10, 4};
        String[] strArray = {"banana", "apple", "grape", "cherry"};

        System.out.println("Original integer array:");
        printArray(intArray);
        quickSort(intArray, 0, intArray.length - 1);
        System.out.println("Sorted integer array:");
        printArray(intArray);

        System.out.println("\nOriginal string array:");
        printArray(strArray);
        quickSort(strArray, 0, strArray.length - 1);
        System.out.println("Sorted string array:");
        printArray(strArray);
    }

    public static <T extends Comparable<T>> void quickSort(T[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    private static <T extends Comparable<T>> int partition(T[] arr, int low, int high) {
        T pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (arr[j].compareTo(pivot) < 0) {
                i++;
                T temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        T temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    public static <T> void printArray(T[] arr) {
        for (T item : arr) {
            System.out.print(item + " ");
        }
        System.out.println();
    }
}
