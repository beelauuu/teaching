public class BinarySearchTree<K extends Comparable<K>>  {
	
	private class Node {
        private K key;
        private Node left, right;

        private Node(K key) {
            this.key = key;
        }
    }
	
	 private Node root;

	 
	/**
	* Checks whether the given key exists in the BST.
	*
	* @param key the key to search for
	* @return true if the key exists, false otherwise
	* @throws IllegalArgumentException if the key is null
	*/
	 
//  Iterative 
//
//	public boolean containsKey(K key) {
//		if(key == null) {
//			throw new IllegalArgumentException("Key can't be null");
//		}
//		
//		Node curr = root;
//		
//		while (curr != null) {
//			int cmp = key.compareTo(curr.key);
//			
//			if(cmp == 0) {
//				return true;
//			}
//			else if(cmp < 0) {
//				curr = curr.left;
//			}
//			else {
//				curr = curr.right;
//			}
//		}
//		
//		return false;
//	}
	 
//	 Recursive
//
//	 public boolean containsKey(K key) {
//		 if(key == null) {
//			 throw new IllegalArgumentException("Key can't be null");
//		 }
//		 
//		 return containsKey(root, key);
//	 }
//	 
//	 private boolean containsKey(Node curr, K key) {
//		 if(curr == null) {
//			 return false;
//		 }
//		 
//		 int cmp = key.compareTo(curr.key);
//		 
//		 if(cmp == 0) {
//			 return true;
//		 }
//		 else if(cmp > 0) {
//			 return containsKey(curr.right, key);
//		 }
//		 else {
//			 return containsKey(curr.left, key);
//		 }
//	 }
	
	
}
