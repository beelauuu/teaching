import java.util.ArrayList;

public class ArrayListDemo {
    public static void main(String[] args) {
        // Creating an ArrayList of Strings
        ArrayList<String> fruits = new ArrayList<>();
        
        // add(E e) - Adding elements to the ArrayList
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Cherry");
        System.out.println("Initial List: " + fruits);
        
        // add(int index, E e) - Inserting an element at a specific index
        fruits.add(1, "Blueberry");
        System.out.println("After inserting Blueberry at index 1: " + fruits);
        
        // get(int index) - Retrieving an element at a specific index
        System.out.println("Element at index 2: " + fruits.get(2));
        
        // set(int index, E e) - Updating an element at a specific index
        fruits.set(2, "Blackberry");
        System.out.println("After updating index 2: " + fruits);
        
        // remove(int index) - Removing an element by index
        fruits.remove(1);
        System.out.println("After removing element at index 1: " + fruits);
        
        // remove(Object o) - Removing an element by value
        fruits.remove("Cherry");
        System.out.println("After removing 'Cherry': " + fruits);
        
        // size() - Getting the number of elements
        System.out.println("Size of the list: " + fruits.size());
        
        // contains(Object o) - Checking if an element exists
        System.out.println("Contains 'Apple'? " + fruits.contains("Apple"));
        System.out.println("Contains 'Mango'? " + fruits.contains("Mango"));
        
        // Iterating over the list using a for-each loop
        System.out.println("Iterating using for-each loop:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }
        
        // Iterating using a traditional for loop
        System.out.println("Iterating using for loop:");
        for (int i = 0; i < fruits.size(); i++) {
            System.out.println(fruits.get(i));
        }
        
        // clear() - Removing all elements from the list
        fruits.clear();
        System.out.println("After clearing the list: " + fruits);
        
        // Tricky remove example with Integer list
        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(1);
        numbers.add(2);
        numbers.add(3);
        numbers.add(4);
        numbers.add(5);
        System.out.println("Initial numbers list: " + numbers);
        
        numbers.remove(3); // Removes element at index 3 (value 4), NOT the number 3
        System.out.println("After remove(3) (removing index 3): " + numbers);
        
        numbers.remove(Integer.valueOf(3)); // Explicitly removes the number 3
        System.out.println("After remove(Integer.valueOf(3)) (removing number 3): " + numbers);
    }
}
