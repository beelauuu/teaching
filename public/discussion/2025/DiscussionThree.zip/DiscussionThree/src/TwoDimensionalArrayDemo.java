import java.util.Arrays;

public class TwoDimensionalArrayDemo {
    public static void main(String[] args) {
        // Creating a 2D integer array
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        
        // Printing the initial 2D array
        System.out.println("Initial 2D Integer Array:");
        printMatrix(matrix);
        
        // Accessing an element
        System.out.println("Element at row 1, column 2: " + matrix[1][2]);
        
        // Modifying an element
        matrix[0][1] = 42;
        System.out.println("After modifying element at row 0, column 1:");
        printMatrix(matrix);
        
        // Iterating over the 2D array using nested loops
        System.out.println("Iterating using nested loops:");
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
        
        // Iterating using an enhanced for loop
        System.out.println("Iterating using enhanced for loop:");
        for (int[] row : matrix) {
            for (int value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
        
        // Getting dimensions
        System.out.println("Number of rows: " + matrix.length);
        System.out.println("Number of columns in row 0: " + matrix[0].length);
        
        // Printing the 2D array using Arrays.deepToString()
        System.out.println("2D Integer Array as String: " + Arrays.deepToString(matrix));
        
        // Creating a 2D string array
        String[][] words = {
            {"Hello", "World"},
            {"Java", "Programming"},
            {"2D", "Array"}
        };
        
        // Printing the initial 2D string array
        System.out.println("\nInitial 2D String Array:");
        printStringMatrix(words);
        
        // Accessing and modifying an element
        words[1][1] = "Coding";
        System.out.println("After modifying element at row 1, column 1:");
        printStringMatrix(words);
        
        // Printing the 2D string array using Arrays.deepToString()
        System.out.println("2D String Array as String: " + Arrays.deepToString(words));
    }
    
    // Helper method to print a 2D integer array
    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
    
    // Helper method to print a 2D string array
    public static void printStringMatrix(String[][] matrix) {
        for (String[] row : matrix) {
            for (String value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
}