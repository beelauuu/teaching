// CountingSortDemo.java
public class CountingSort {

    /**
     * Performs Counting Sort on a non-negative integer array.
     * Assumes elements are in the range [0, maxValue].
     *
     * Time Complexity:
     *   - O(n + k), where:
     *       n = number of elements in the input array
     *       k = maxValue (range of input values)
     *
     * Space Complexity:
     *   - O(k) for the count array
     *
     * Counting Sort is not comparison-based and works best when
     * the input range (k) is not significantly larger than the number of elements.
     */
    public static void countingSort(int[] arr, int maxValue) {
        // Step 1: Initialize count array of size maxValue + 1
        // This stores how many times each value appears in arr
        int[] count = new int[maxValue + 1];  // O(k) space

        // Step 2: Count occurrences of each number in arr
        // Traverse the array once → O(n) time
        for (int num : arr) {
            count[num]++;
        }

        // Step 3: Reconstruct the sorted array
        // For each value i in count, write it count[i] times to arr
        // This loop runs in O(n + k) time in total
        int index = 0;
        for (int i = 0; i <= maxValue; i++) {
            while (count[i] > 0) {
                arr[index++] = i;
                count[i]--;
            }
        }
    }

    // Utility function to print the array contents
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        // Sample input array with integers in the range [1, 8]
        int[] arr = {4, 2, 2, 8, 3, 3, 1};
        int maxValue = 8;  // Known maximum value in the input

        System.out.println("Before sorting:");
        printArray(arr);

        // Call counting sort
        countingSort(arr, maxValue);

        System.out.println("After counting sort:");
        printArray(arr);
    }
}
