import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        // Creating a Stack
        Stack<String> stack = new Stack<>();

        // push() - Pushing elements onto the stack
        stack.push("First");
        stack.push("Second");
        stack.push("Third");
        System.out.println("Stack after push operations: " + stack);

        // peek() - Checking the top element
        System.out.println("Top element (peek): " + stack.peek());

        // pop() - Removing and returning the top element
        System.out.println("Popped: " + stack.pop());
        System.out.println("Popped: " + stack.pop());

        // Stack after pop operations
        System.out.println("Stack after pop operations: " + stack);
    }
}
