import java.util.Vector;

public class VectorExample {
    public static void main(String[] args) {
        // Creating a Vector with initial capacity of 3
        Vector<Integer> vector = new Vector<>(3);

        // addElement() - Adds an element (same as add())
        vector.addElement(10);
        vector.addElement(20);
        vector.addElement(30);
        System.out.println("Vector after addElement(): " + vector);

        // elementAt() - Retrieves an element at index 1
        System.out.println("Element at index 1: " + vector.elementAt(1));

        // removeElement() - Removes the first occurrence of 20
        vector.removeElement(20);
        System.out.println("Vector after removeElement(20): " + vector);

        // capacity() - Returns current capacity of the vector
        System.out.println("Vector capacity: " + vector.capacity());

        // Adding more elements to trigger capacity increase
        vector.addElement(40);
        vector.addElement(50);
        System.out.println("Vector after adding more elements: " + vector);
        System.out.println("Updated capacity: " + vector.capacity());

        // trimToSize() - Reduces capacity to current size
        vector.trimToSize();
        System.out.println("Capacity after trimToSize(): " + vector.capacity());
    }
}
