import java.util.*;

// Implementing Comparable in the Employee class
class Employee implements Comparable<Employee> {
    String name;
    double salary;

    Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    // Default sorting by salary (ascending order)
    @Override
    public int compareTo(Employee other) {
        return Double.compare(this.salary, other.salary);
    }

    @Override
    public String toString() {
        return name + " ($" + salary + ")";
    }
}

// Implementing Comparator separately for different sorting logic
class NameComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return e1.name.compareTo(e2.name); // Sorting alphabetically by name
    }
}

class ReverseSalaryComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return Double.compare(e2.salary, e1.salary); // Sorting by salary in descending order
    }
}

public class ComparatorVsComparable {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Alice", 75000));
        employees.add(new Employee("Bob", 50000));
        employees.add(new Employee("Charlie", 60000));

        // Sorting using Comparable (Default: By Salary Ascending)
        Collections.sort(employees);
        System.out.println("Sorted by Salary (Comparable): " + employees);

        // Sorting using Comparator (By Name Alphabetically)
        employees.sort(new NameComparator());
        System.out.println("Sorted by Name (Comparator): " + employees);

        // Sorting using Comparator (By Salary Descending)
        employees.sort(new ReverseSalaryComparator());
        System.out.println("Sorted by Salary Descending (Comparator): " + employees);
    }
}
