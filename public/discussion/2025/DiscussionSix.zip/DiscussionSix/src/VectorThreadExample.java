import java.util.Vector;

public class VectorThreadExample {
    public static void main(String[] args) {
        Vector<Integer> vector = new Vector<>();

        Thread t1 = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                vector.add(i);
                System.out.println("Thread 1 added: " + i);
            }
        });

        Thread t2 = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                vector.add(i * 10);
                System.out.println("Thread 2 added: " + (i * 10));
            }
        });

        t1.start();
        t2.start();

        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final Vector: " + vector);
        System.out.println("Vector size: " + vector.size());   
   }
    
}
