import java.util.ArrayList;
import java.util.List;

public class ArrayListThreadExample {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();

        // Create two threads that modify the list concurrently
        Thread t1 = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                list.add(i);
                System.out.println("Thread 1 added: " + i);
//                sleep(100);
            }
        });

        Thread t2 = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                list.add(i * 10);
                System.out.println("Thread 2 added: " + (i * 10));
//                sleep(100);
            }
        });

        t1.start();
        t2.start();

        // Wait for threads to complete execution
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Print final list
        System.out.println("Final List: " + list);
        System.out.println("List size: " + list.size()); 
    }

    // Helper method to simulate thread sleep
    private static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
