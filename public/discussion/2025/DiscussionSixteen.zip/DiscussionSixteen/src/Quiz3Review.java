/**
 * CMSC132 - Quiz 3 Review
 * This file covers key concepts about Maps and Sets to prepare for Quiz 3
 */
import java.util.*;

public class Quiz3Review {
    
    public static void main(String[] args) {
        System.out.println("Maps and Sets Review for Quiz 3\n");
        
        // Example of recursive Map operations
        System.out.println("=== RECURSIVE MAP OPERATIONS ===");
        demonstrateRecursiveMapExample();
        
        // Map types overview with examples
        System.out.println("\n=== MAP TYPES OVERVIEW WITH EXAMPLES ===");
        demonstrateMapTypes();
        
        // Set types overview with examples
        System.out.println("\n=== SET TYPES OVERVIEW WITH EXAMPLES ===");
        demonstrateSetTypes();
    }
    
    /**
     * Demonstrates recursive operations with Maps
     */
    private static void demonstrateRecursiveMapExample() {
        // Example 1: Count occurrences of each character in a string recursively
        System.out.println("Example 1: Count character occurrences recursively");
        java.util.Map<Character, Integer> charCounts = new java.util.HashMap<>();
        String testString = "Mississippi";
        countChars(testString, 0, charCounts);
        System.out.println("Character counts in '" + testString + "': " + charCounts);
                
        // Example 2: Add entries from array to map recursively
        System.out.println("\nExample 3: Add array elements to map recursively");
        String[] words = {"apple", "banana", "apple", "cherry", "banana", "date"};
        java.util.Map<String, Integer> wordCounts = new java.util.HashMap<>();
        countArrayElements(words, 0, wordCounts);
        System.out.println("Word counts: " + wordCounts);
    }
    
    /**
     * Recursively counts occurrences of each character in a string
     * @param str the input string
     * @param index current position in string
     * @param map the map to store character counts
     */
    private static void countChars(String str, int index, java.util.Map<Character, Integer> map) {
        // Base case: reached end of string
        if (index >= str.length()) {
            return;
        }
        
        // Get current character
        char c = str.charAt(index);
        
        // Update count in map (using only put as required)
        Integer currentCount = map.get(c);
        if (currentCount == null) {
            map.put(c, 1);
        } else {
            map.put(c, currentCount + 1);
        }
        
        // Recursive call for next character
        countChars(str, index + 1, map);
    }
    
    /**
     * Recursively counts occurrences of elements in an array
     * @param array input array
     * @param index current position in array
     * @param map the map to store element counts
     */
    private static void countArrayElements(String[] array, int index, java.util.Map<String, Integer> map) {
        // Base case: reached end of array
        if (index >= array.length) {
            return;
        }
        
        // Get current element
        String element = array[index];
        
        // Update count in map (using only put as specified)
        Integer currentCount = map.get(element);
        if (currentCount == null) {
            map.put(element, 1);
        } else {
            map.put(element, currentCount + 1);
        }
        
        // Recursive call for next element
        countArrayElements(array, index + 1, map);
    }
    
    /**
     * Demonstrates different Map types with examples
     */
    private static void demonstrateMapTypes() {
        // Sample data
        String[] names = {"Kim", "Alex", "Bob", "David", "Charlie", "Emma"};
        
        // 1. HashMap Example
        System.out.println("1. HashMap Example:");
        Map<String, Integer> hashMap = new HashMap<>();
        for (int i = 0; i < names.length; i++) {
            hashMap.put(names[i], names[i].length());
        }
        System.out.println("   HashMap (unordered): " + hashMap);
        System.out.println("   - Notice: Elements appear in no particular order");
        
        // 2. LinkedHashMap Example
        System.out.println("\n2. LinkedHashMap Example:");
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        for (int i = 0; i < names.length; i++) {
            linkedHashMap.put(names[i], names[i].length());
        }
        System.out.println("   LinkedHashMap (insertion order): " + linkedHashMap);
        System.out.println("   - Notice: Elements maintain insertion order (Kim, Alex, Bob, etc.)");
        
        // 3. TreeMap Example
        System.out.println("\n3. TreeMap Example:");
        Map<String, Integer> treeMap = new TreeMap<>();
        for (int i = 0; i < names.length; i++) {
            treeMap.put(names[i], names[i].length());
        }
        System.out.println("   TreeMap (natural order): " + treeMap);
        System.out.println("   - Notice: Elements are sorted alphabetically (Alex, Bob, Charlie, etc.)");
        
        // 4. TreeMap with Custom Comparator Example
        System.out.println("\n4. TreeMap with Custom Comparator Example:");
        Map<String, Integer> customTreeMap = new TreeMap<>(new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                // Sort by string length, then alphabetically if same length
                int lengthCompare = Integer.compare(s1.length(), s2.length());
                if (lengthCompare != 0) {
                    return lengthCompare;
                }
                return s1.compareTo(s2);
            }
        });
        for (int i = 0; i < names.length; i++) {
            customTreeMap.put(names[i], names[i].length());
        }
        System.out.println("   TreeMap (custom order by length): " + customTreeMap);
        System.out.println("   - Notice: Elements are sorted by name length, then alphabetically");
        
        // Performance comparison example
        System.out.println("\n5. Map Performance Comparison Example:");
        System.out.println("   Each Map type has different performance characteristics.");
        System.out.println("   • HashMap: O(1) for put/get/remove operations");
        System.out.println("   • LinkedHashMap: O(1) for put/get/remove operations with slight overhead");
        System.out.println("   • TreeMap: O(log n) for put/get/remove operations");
        
        // Key-Value relationship example
        System.out.println("\n6. Key-Value Relationship Example:");
        Map<String, List<String>> courseStudents = new HashMap<>();
        addStudentToCourse(courseStudents, "CS101", "Alice");
        addStudentToCourse(courseStudents, "CS101", "Bob");
        addStudentToCourse(courseStudents, "CS201", "Charlie");
        addStudentToCourse(courseStudents, "CS201", "David");
        addStudentToCourse(courseStudents, "CS101", "Emma");
        System.out.println("   Course to Students Map: " + courseStudents);
    }
    
    /**
     * Helper method for adding a student to a course in a Map
     */
    private static void addStudentToCourse(Map<String, List<String>> map, String course, String student) {
        if (!map.containsKey(course)) {
            map.put(course, new ArrayList<>());
        }
        map.get(course).add(student);
    }
    
    /**
     * Demonstrates different Set types with examples
     */
    private static void demonstrateSetTypes() {
        // Sample data
        String[] colors = {"Red", "Blue", "Green", "Yellow", "Orange", "Blue", "Red", "Purple"};
        
        System.out.println("Original array with duplicates: " + Arrays.toString(colors));
        
        // 1. HashSet Example
        System.out.println("\n1. HashSet Example:");
        Set<String> hashSet = new HashSet<>();
        for (String color : colors) {
            hashSet.add(color);
        }
        System.out.println("   HashSet (unordered): " + hashSet);
        System.out.println("   - Notice: Duplicates removed, elements in no particular order");
        
        // 2. LinkedHashSet Example
        System.out.println("\n2. LinkedHashSet Example:");
        Set<String> linkedHashSet = new LinkedHashSet<>();
        for (String color : colors) {
            linkedHashSet.add(color);
        }
        System.out.println("   LinkedHashSet (insertion order): " + linkedHashSet);
        System.out.println("   - Notice: Duplicates removed, elements in order of first insertion");
        
        // 3. TreeSet Example
        System.out.println("\n3. TreeSet Example:");
        Set<String> treeSet = new TreeSet<>();
        for (String color : colors) {
            treeSet.add(color);
        }
        System.out.println("   TreeSet (natural order): " + treeSet);
        System.out.println("   - Notice: Duplicates removed, elements in alphabetical order");
        
        // 4. TreeSet with Custom Comparator Example
        System.out.println("\n4. TreeSet with Custom Comparator Example:");
        Set<String> customTreeSet = new TreeSet<>(new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                // Sort by string length, then alphabetically if same length
                int lengthCompare = Integer.compare(s1.length(), s2.length());
                if (lengthCompare != 0) {
                    return lengthCompare;
                }
                return s1.compareTo(s2);
            }
        });
        for (String color : colors) {
            customTreeSet.add(color);
        }
        System.out.println("   TreeSet (custom order by length): " + customTreeSet);
        System.out.println("   - Notice: Duplicates removed, elements sorted by length then alphabetically");
        
        // 5. Set Operations Example
        System.out.println("\n5. Set Operations Example:");
        Set<String> set1 = new HashSet<>(Arrays.asList("A", "B", "C", "D"));
        Set<String> set2 = new HashSet<>(Arrays.asList("C", "D", "E", "F"));
        
        // Create copies for operations
        Set<String> unionSet = new HashSet<>(set1);
        unionSet.addAll(set2);
        
        Set<String> intersectionSet = new HashSet<>(set1);
        intersectionSet.retainAll(set2);
        
        Set<String> differenceSet = new HashSet<>(set1);
        differenceSet.removeAll(set2);
        
        System.out.println("   Set 1: " + set1);
        System.out.println("   Set 2: " + set2);
        System.out.println("   Union (set1 ∪ set2): " + unionSet);
        System.out.println("   Intersection (set1 ∩ set2): " + intersectionSet);
        System.out.println("   Difference (set1 - set2): " + differenceSet);
        
        // 6. Set Performance Comparison Example
        System.out.println("\n6. Set Performance Characteristics:");
        System.out.println("   Each Set type has different performance characteristics:");
        System.out.println("   • HashSet: O(1) for add/contains/remove operations");
        System.out.println("   • LinkedHashSet: O(1) for add/contains/remove with slight overhead for order");
        System.out.println("   • TreeSet: O(log n) for add/contains/remove operations");
        
        // 7. Set implementation considerations
        System.out.println("\n7. Important Set Implementation Considerations:");
        System.out.println("   • For HashSet/LinkedHashSet objects need proper hashCode() and equals()");
        System.out.println("   • For TreeSet objects must implement Comparable or use a Comparator");
        System.out.println("   • HashSet allows one null element");
        System.out.println("   • LinkedHashSet allows one null element");
        System.out.println("   • TreeSet does NOT allow null elements (will throw NullPointerException)");
    }
}