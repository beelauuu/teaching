public class MergeSortGeneric {

    // Public method to initiate merge sort on an entire generic array
    public static <T extends Comparable<T>> void mergeSort(T[] arr) {
        if (arr == null || arr.length <= 1) {
            return; // already sorted or empty
        }
        mergeSort(arr, 0, arr.length - 1);
    }

    // Recursive method that sorts arr[from...to]
    private static <T extends Comparable<T>> void mergeSort(T[] arr, int from, int to) {
        if (from >= to) {
            return; // base case: one element
        }

        int mid = (from + to) / 2;

        // Recursively sort the left half
        mergeSort(arr, from, mid);

        // Recursively sort the right half
        mergeSort(arr, mid + 1, to);

        // Merge the two sorted halves
        merge(arr, from, mid, to);
    }

    // Merge two sorted subarrays: arr[from...mid] and arr[mid+1...to]
    private static <T extends Comparable<T>> void merge(T[] arr, int from, int mid, int to) {
        @SuppressWarnings("unchecked")
		T[] temp = (T[]) new Comparable[to - from + 1];

        int i = from;      // pointer for left half
        int j = mid + 1;   // pointer for right half
        int k = 0;         // pointer for temp array

        // Merge elements into temp in sorted order
        while (i <= mid && j <= to) {
            if (arr[i].compareTo(arr[j]) <= 0) {
                temp[k++] = arr[i++];
            } else {
                temp[k++] = arr[j++];
            }
        }

        // Copy remaining elements from left half (if any)
        while (i <= mid) {
            temp[k++] = arr[i++];
        }

        // Copy remaining elements from right half (if any)
        while (j <= to) {
            temp[k++] = arr[j++];
        }

        // Copy sorted values back into original array
        for (int p = 0; p < temp.length; p++) {
            arr[from + p] = temp[p];
        }
    }

    // Test with different types
    public static void main(String[] args) {
        Integer[] nums = { 38, 27, 43, 3, 9, 82, 10 };
        mergeSort(nums);
        for (int n : nums) {
            System.out.print(n + " ");
        }
        System.out.println();

        String[] words = { "banana", "apple", "grape", "cherry" };
        mergeSort(words);
        for (String word : words) {
            System.out.print(word + " ");
        }
    }
}
